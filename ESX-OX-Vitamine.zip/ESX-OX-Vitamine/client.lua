ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        ESX = exports["es_extended"]:getSharedObject()
        Citizen.Wait(0)
    end
end)

RegisterNetEvent('ox_inventory:useItem')
AddEventHandler('ox_inventory:useItem', function(item)
    if item.name == 'vitamine' then
        local playerPed = PlayerPedId()

        -- Jouer l'animation de boire
        RequestAnimDict("mp_player_intdrink")
        while not HasAnimDictLoaded("mp_player_intdrink") do
            Citizen.Wait(100)
        end
        TaskPlayAnim(playerPed, "mp_player_intdrink", "loop_bottle", 8.0, -8, -1, 49, 0, false, false, false)
        Citizen.Wait(3000) -- Durée de l'animation

        ClearPedTasks(playerPed)

        -- Notification de l'utilisation de la vitamine
        ESX.ShowNotification('Vous avez utilisé une vitamine. Votre stamina est inépuisable pendant 10 minutes.')

        -- Rendre la stamina inépuisable pendant 10 minutes
        Citizen.CreateThread(function()
            local startTime = GetGameTimer()

            while GetGameTimer() - startTime < 600000 do -- 10 minutes en millisecondes
                ResetPlayerStamina(PlayerId())
                Citizen.Wait(100)
            end

            ESX.ShowNotification('L\'effet de la vitamine a disparu.')
        end)

        -- Supprimer l'item de l'inventaire
        TriggerServerEvent('ox_inventory:removeItem', 'vitamine', 1)
    end
end)