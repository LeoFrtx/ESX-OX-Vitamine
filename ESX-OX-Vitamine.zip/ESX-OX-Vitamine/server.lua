ESX = nil

-- Initialisation de ESX
ESX = exports["es_extended"]:getSharedObject()

-- Enregistrer l'item utilisable
ESX.RegisterUsableItem('vitamine', function(source)
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.removeInventoryItem('vitamine', 1)
    TriggerClientEvent('ox_inventory:useItem', source, { name = 'vitamine' })
end)