fx_version 'adamant'

game 'gta5'

description 'Vitamine Item ox_inventory'

version '1.0.0'

author 'Léo'

shared_script '@es_extended/imports.lua'

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}

dependencies {
    'es_extended',
    'ox_inventory'
}